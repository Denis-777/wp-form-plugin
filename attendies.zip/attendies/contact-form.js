jQuery(document).ready(function(jQuery){

	var form = jQuery('.register-form'),
		action = form.attr('action'),
		pattern = /^([a-z0-9_\.-])+@[a-z0-9-]+\.([a-z]{2,4}\.)?[a-z]{2,4}jQuery/i;

	form.find('.req-field').addClass('empty-field');

	function checkInput() {
		form.find('.req-field').each(function () {
			var el = jQuery(this);
			if (el.hasClass('rf-mail')) {
				if (pattern.test(el.val())) {
					el.removeClass('empty-field');
				} else {
					el.addClass('empty-field');
				}
			} else if (el.val() != '') {
				el.removeClass('empty-field');
			} else {
				el.addClass('empty-field');
			}
		});
	}

	function lightEmpty() {
		form.find('.empty-field').addClass('rf-error');
		setTimeout(function () {
			form.find('.rf-error').removeClass('rf-error');
		}, 1000);
	}

	jQuery(document).on('submit', '.register-form', function (e) {
		var formData = {
			name: jQuery('#att_name').prop('value'),
			email: jQuery('#att_email').prop('value'),
			event: jQuery('#concert').prop('value'),
			check: jQuery('#terms_check').prop('checked'),
		};
		
		if(formData['check']==true && formData['name'].length!=0 && formData['email'].length!=0){
			jQuery('#spinner').css("display","block");
			jQuery.ajax({
				type: 'POST',
				url: action,
				data: formData,
				beforeSend: function () {
					form.addClass('is-sending');
				},
				error: function (request, txtstatus, errorThrown) {
					console.log(request);
					console.log(txtstatus);
					console.log(errorThrown);
				},
				success: function () {
					form.removeClass('is-sending').addClass('is-sending-complete');
					jQuery('#spinner').css("display","none");
					jQuery("#success-alert").show('slow');
					setTimeout(function() { jQuery("#success-alert").hide('slow'); }, 2000);
				}
			});
		}
		else{
			jQuery("#error-alert").show('slow');
			setTimeout(function() { jQuery("#error-alert").hide('slow'); }, 2000);
		}
		e.preventDefault();

	});

	jQuery(document).on('click', '.register-form button[type="submit"]', function (e) {

		checkInput();

		var errorNum = form.find('.empty-field').length;

		if (errorNum > 0) {
			lightEmpty();
			e.preventDefault();
		}

	});

	jQuery(document).on('click', '.form-is-more button', function () {

		form.find('input').val('');

		form.find('textarea').val('');

		form.removeClass('is-sending-complete');

	});

});
