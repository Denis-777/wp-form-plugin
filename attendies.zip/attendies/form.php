<div class="hcf_box">
    <style scoped>
        .hcf_box{
            display: grid;
            grid-template-columns: max-content 1fr;
            grid-row-gap: 10px;
            grid-column-gap: 20px;
        }
        .hcf_field{
            display: contents;
        }
    </style>
    <p class="meta-options hcf_field">
        <label for="name">Name</label>
        <input id="name"
            type="text"
            name="name"
            value="<?php echo esc_attr( get_post_meta( get_the_ID(), 'name', true ) ); ?>">
    </p>
    <p class="meta-options hcf_field">
        <label for="email">Email</label>
        <input id="email"
            type="text"
            name="email"
            value="<?php echo esc_attr( get_post_meta( get_the_ID(), 'email', true ) ); ?>">
    </p>
    <p class="meta-options hcf_field">
        <label for="event">Event</label>
		<select name="event" id="event" style="width: 100%;" value="<?php echo esc_attr( get_term_meta( $term->term_id, 'meta_description', 1 ) ) ?>">
					  <option value="Concert1">Concert1</option>
					  <option value="Concert2">Concert2</option>
					  <option value="Concert3">Concert3</option>
		</select>
    </p>
</div>