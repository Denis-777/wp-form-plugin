<?php
/**
 * Attendies plugin
 *
 * @package       Attendies plugin
 * @author        Denis
 * @version       1.0.0
 *
 * @wordpress-plugin
 * Plugin Name:   Attendies
 * Description:   Plugin for inviting attendies for an event
 * Version:       1.0.0
 * Author:        Denis
 * Author URI:    https://your-author-domain.com
 * Text Domain:   Denis Content Settings Plugin
 * Domain Path:   /languages
 */
 
// Add new custom post type
 
add_action( 'init', 'cpt_attendies_list' );

function cpt_attendies_list() {

    $labels = array(
        "name" => "Attendies",
        "singular_name" => "Attendies",
        "menu_name" => "Attendies",
        "all_items" => "All attendies",
        "add_new" => "Add New",
        "add_new_item" => "Add New",
        "edit" => "Edit",
        "edit_item" => "Edit",
        "new_item" => "New item",
        "view" => "View",
        "view_item" => "View item",
        "search_items" => "Search item",
        "not_found" => "No found",
        "not_found_in_trash" => "No found",
    );

    $args = array(
        "labels" => $labels,
        "description" => "",
        "public" => true,
        "show_ui" => true,
        "has_archive" => false,
        "show_in_menu" => true,
        "exclude_from_search" => true,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => true,
        "rewrite" => false,
        "query_var" => true,
        "menu_position" => 7,
        "menu_icon" => "dashicons-groups",
        "supports" => array("custom-fields" ),
    );

    register_post_type( "attendee", $args );
	
}


// Create new columns and remove old ones

function true_add_columns( $my_columns ) {
	
	if($my_columns['description']){
		unset($my_columns['description']);
		unset($my_columns['slug']);
		echo "<style> .term-description-wrap { display:none; } </style>";
		echo "<style> .term-slug-wrap { display:none; } </style>";
		echo "<style> .term-parent-wrap { display:none; } </style>";
	}
 
	// New columns 
	$preview = array( 'name' => 'Full Name' , 'email' => 'Email', 'event'  => 'Event');
 
	// Insert new columns
	$my_columns = array_slice( $my_columns, 0, 1, true ) + $preview;
 
	return $my_columns;
 
}

add_filter( 'manage_edit-attendee_columns', 'true_add_columns', 25 );
 
 
// Fullfill columns in attendee table

function wp_kama_manage_screen_taxonomy_custom_column_filter( $column_name, $term_id ){

	// filter...
	$name = get_post_meta( $term_id , 'name', false );
	if( !empty($name) && $column_name=='name'){
			echo $name[0];
	}
	$email = get_post_meta( $term_id , 'email', false );
	if( !empty($email) && $column_name=='email'){
			echo $email[0]; 
	}
	$event = get_post_meta( $term_id , 'event', false );
	if( !empty($event) && $column_name=='event'){
			echo $event[0]; 
	}
	return $column_name;
}
add_filter( 'manage_attendee_posts_custom_column', 'wp_kama_manage_screen_taxonomy_custom_column_filter', 10, 3 );

// remove columns for description, slag
//add_filter( 'manage_edit-person_columns', 'true_add_columns', 25 );


/**
 * Register meta boxes.
 */
function hcf_register_meta_boxes() {
    add_meta_box( 'hcf-1', __( 'Attendee data', 'hcf' ), 'hcf_display_callback', 'attendee' );
}
add_action( 'add_meta_boxes', 'hcf_register_meta_boxes' );

/**
 * Meta box display callback.
 *
 * @param WP_Post $post Current post object.
 */

function hcf_display_callback( $post ) {
	include plugin_dir_path( __FILE__ ) . './form.php';
}
/**
 * Save meta box content.
 *
 * @param int $post_id Post ID
 */
/**
 * Save meta box content.
 *
 * @param int $post_id Post ID
 */
function hcf_save_meta_box( $post_id ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( $parent_id = wp_is_post_revision( $post_id ) ) {
        $post_id = $parent_id;
    }
    $fields = [
        'name',
        'email',
        'event',
    ];
    foreach ( $fields as $field ) {
        if ( array_key_exists( $field, $_POST ) ) {
            update_post_meta( $post_id, $field, sanitize_text_field( $_POST[$field] ) );
        }
     }
}
add_action( 'save_post', 'hcf_save_meta_box' );

// Add shortcode
add_shortcode('register-form', 'attendee_form');

// Output the form

function attendee_form($atts) {
	?>
	<form action="<?php echo admin_url('admin-ajax.php?action=send_mail'); ?>" method="post" class="register-form">

			<h5>Become a concert attendee</h5>
			<label>Your name</label>
			<input id="att_name" type="text" name="name" placeholder="First and Last Name"/>
			<br>
			<label>Your Email</label>
			<input  id="att_email" type="email" name="email" placeholder="Email"/>
			<br>
			<label>Choose event</label>
			<select name="concert" id="concert" style="width: 100%; padding: 1.5rem 1.8rem;">
			  <option value="Concert1">Concert1</option>
			  <option value="Concert2">Concert2</option>
			  <option value="Concert3">Concert3</option>
			</select>
			<br><br>
			<div class="terms">
			<p style="color:grey!important;">Terms and Conditions</p>
			<p>Lorem ipsum...</p>
			<input type="checkbox" id="terms_check" name="terms_check" value="Bike">
			<span>I am agree</span>
			</div>
			<br>
			<p id="success-alert">Your request has been sent successfully</p>
			<p id="error-alert">Your request has an error. Please, check the fields.</p>
			
			<button type="submit" style="">Send</button>
			
			<div class="form-is-sending" id="spinner">
				<span class="pa-spinner"></span>
			</div>

			<div class="form-is-more" id="more-button">
				<button type="button">
					Send more
				</button>
			</div>
	
	</form>
	<?php
}

// Save form data into db 

function send_mail() {

  /* Get data */
  $client_name = $_POST['name'];

  /* Create new post */
  $post_data = array(
   'post_title'    => $client_name,
   'post_content'  => '',
   'name'          => $client_fio,
   'post_status'   => 'publish',
   'post_author'   => 1,
   'post_type' => 'attendee',
  );

  $post_id = wp_insert_post( $post_data );
  
  $fields = [
        'name',
        'email',
        'event',
    ];
    foreach ( $fields as $field ) {
        if ( array_key_exists( $field, $_POST ) ) {
            update_post_meta( $post_id, $field, sanitize_text_field( $_POST[$field] ) );
        }
     }
  
  
 

  /* End ajax */
  die();
  
}

add_action("wp_ajax_send_mail", "send_mail");
add_action("wp_ajax_nopriv_send_mail", "send_mail");

// Connect js and css files
add_action( 'wp_enqueue_scripts', 'safely_add_stylesheet' );

    /**
     * Add stylesheet to the page
     */
    function safely_add_stylesheet() {
        wp_enqueue_style( 'prefix-style', plugins_url('style.css', __FILE__) );
		
}
add_action( 'wp_enqueue_scripts', 'safely_add_script' );

    /**
     * Add script to the page
     */
    function safely_add_script() {
       wp_enqueue_script('contact-form-js', plugins_url('contact-form.js', __FILE__), array("jquery"), false);
		
}


